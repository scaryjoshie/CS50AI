ex = {1, 2, 3}
import random
random.choice(list(ex))