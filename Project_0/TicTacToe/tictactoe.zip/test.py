node = 5
current_node = node
current_node = 3
print(node)