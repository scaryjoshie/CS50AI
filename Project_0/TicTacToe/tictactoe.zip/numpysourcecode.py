# just kidding
print(not False)